package admin;

public class CategoryBean {

		private int ctg_num;
		private String ctg_name;
		
		public int getCtg_num() {return ctg_num;}
		public String getCtg_name() {return ctg_name;}
		
		public void setCtg_num(int ctg_num) {this.ctg_num = ctg_num;}
		public void setCtg_name(String ctg_name) {this.ctg_name = ctg_name;}
}
